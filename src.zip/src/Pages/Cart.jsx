import React from 'react'
import { Button, Table } from 'react-bootstrap'
import { useDispatch, useSelector } from 'react-redux'
import { removeFromCart } from '../redux/slice/Cartslice'

function Cart() {
  const cartArray = useSelector(state => state.cartreducer)
  const dispatch =useDispatch()
  return (
    <div>
      <div className="cartcontainer container-lg" style={{ marginTop: '100px' }}>
        <h1>Shopping Cart</h1>
        {
          cartArray.length > 0 ?

            <div className='row'>
              <div className="col-lg-8">
                <div className="table shadow rounded">
                  <Table>
                    <thead>

                      <th>#</th>
                      <th>product</th>
                      <th>product image</th>
                      <th>price</th>
                      <th>action</th>
                    </thead>
                    <tbody>
                      {
                        cartArray.map((products, index) =>
                        (<tr key={index}>
                          <td>{index + 1}</td>
                          <td>{products.title}</td>
                          <td><img src={products.thumbnail} width={'100px'} height={'100px'} className='img' alt="" /></td>
                          <td>{products.price}</td>
                          <td><Button className='btn btn-light' onClick={()=>dispatch(removeFromCart(products.id))} ><i className='fa-solid fa-trash text-danger'></i></Button></td>
                        </tr>


                        ))
                      }
                    </tbody>
                  </Table>
                </div>
              </div>
            </div> : <p>Cart is Empty</p>
        }

      </div>


    </div>
  )
}

export default Cart